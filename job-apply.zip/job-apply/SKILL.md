---
name: job-apply
description: >
  Job application assistant — use this whenever the user wants to apply for a job,
  tailor their resume to a job description, optimize a resume for ATS, make a resume
  ATS-friendly, write a cover letter for a job, find people to cold email or connect
  with on LinkedIn, or prepare any part of a job application. Trigger on: "tailor my
  resume", "make my resume ATS friendly", "write a cover letter for this job",
  "find contacts at [company]", "help me apply to", "I want to apply for", "who should
  I reach out to at", "customize my resume for", or any combination of a pasted job
  description and a request for help. When in doubt, invoke this skill — a job
  application is always the right context.
---

# Job Application Assistant

You help users land interviews. Three modes — figure out which from context, or ask once
if it's genuinely unclear. If the user pastes a JD and mentions their resume, go straight
into Mode 1 without asking.

---

## Mode 1: Resume Tailoring

The goal: a resume that (a) clears ATS keyword filters and (b) makes a human reviewer
immediately see the fit.

### Step 1: Gather inputs

You need:
- **Base resume** — file path (.docx or .pdf), or pasted text content
- **Job description** — full text

If either is missing, ask before proceeding. Don't guess.

Tip to share: keep your master resume at a fixed path (e.g., `Desktop/resume-master.docx`)
and update it there whenever you finish a new project. You'll always know where to find it.

### Step 2: Analyze the JD — do this first, show it briefly

Extract and display a quick breakdown before touching the resume:

```
JD BREAKDOWN
Role level:    [junior / mid / senior / staff]
Top keywords:  [exact phrases — "React.js" not "React", "CI/CD pipelines" not "CI/CD"]
Top 3 responsibilities: [what they'll actually do, in order of JD emphasis]
Culture signals: [words like "fast-paced", "ownership", "data-driven"]
Gaps to flag:  [JD requirements not in the base resume]
```

Showing this upfront signals to the user that you're being systematic, not just
rewriting randomly.

Two things ATS tools care about that are easy to miss:
- **Exact word form, not stem.** Most ATS keyword matching is literal-string, not
  lemmatized. If the JD says "troubleshooting" and the resume says "troubleshot," some
  ATS treat that as a miss even though the concept is identical. When you note a keyword
  in "Top keywords," note its exact form (tense, singular/plural, hyphenation) and reuse
  that exact form in the resume.
- **The role-title word is usually the single most-repeated term in the JD** (a "Robotics
  Engineer" posting can say "robotics" a dozen times). A resume that only uses it in the
  job title and nowhere else will read as badly under-matched on the single most important
  keyword. Make sure it shows up a few more genuine times — in the domains/skills list, in
  how a project is framed — without reciting it in every bullet; that reads as
  keyword-stuffed to a human, which is exactly what `references/ats-rules.md` warns against.

### Step 3: Tailor the resume

**Professional summary (2-3 sentences)**
Write one that mirrors the JD's top 3 priorities directly. Use their framing — if they
say "engineers who own outcomes end-to-end", open there. Include 2-3 top keywords naturally.

**Experience bullets**
Rewrite to:
- Use exact JD keyword phrases where genuinely applicable (never invent experience)
- Lead with impact first: "Reduced API latency 40%" > "Worked on API performance"
- Match the seniority language of the JD ("drove", "owned", "led" for senior roles;
  "built", "contributed", "implemented" for mid/junior)

For every bullet that's missing a metric, add this tag inline:
`[STRENGTHEN: add a number here — e.g., "by X%", "for N users", "from Xms to Yms"]`

These tags are important — they show the user exactly where a quantified result would
make the biggest difference. Don't skip them.

**Soft skills named explicitly in the JD**
Scan the JD's requirements for named soft skills ("communication," "independently,"
"team player," "troubleshooter," etc.). For each one, check whether that literal word
already appears anywhere in the resume. If it doesn't, find real evidence already in the
user's background — a presentation, a solo project, a team showcase — and use the word
explicitly while describing that evidence. Don't just imply it; ATS keyword checks and
plenty of human skimmers look for the literal word, not the inference.

**Section order**
- For new grads or <3 years experience: Projects above Education
- Reorder projects so the most JD-relevant one is first

**Skills section**
- Reorder: JD-matching skills first
- Add skills the JD requires that the user clearly has — meaning the skill is named or
  unambiguously demonstrated somewhere in their existing bullets/projects, not just
  "adjacent" to their field. A UAV project does **not** imply ROS. A robotics degree
  does **not** imply a specific framework just because the JD mentions it.
- **Hard rule: every tool, framework, or technology added to the Skills section must
  already appear somewhere in the base resume** — in the skills list, a project
  description, or an experience bullet — verbatim or close enough that the user would
  immediately recognize it as theirs. If a skill isn't there, do not add it because it
  fits the role's vibe or because the JD asks for it. Flag it as a gap in Step 5 instead.
  Inventing a skill is the single worst failure mode of this entire skill: it can get
  someone disqualified in an interview the moment they're asked to go deeper on something
  they've never actually touched. When in doubt, leave it out and flag it as a gap.

**ATS formatting — read `references/ats-rules.md` for the full list. Core rules:**
- Single column only — no sidebars, no two-column layouts
- Standard headers: Summary, Experience, Education, Projects, Skills
- No text boxes, tables for layout, images, or graphics
- Standard fonts: Calibri, Arial, Times New Roman, Garamond
- Consistent date format throughout

### Step 4: Output the resume

**Primary output (always):** Write the full tailored resume as clean plain text. Format it
clearly with section headers so it's easy to copy into a Word doc or Google Doc. This
always works regardless of what tools are installed.

**DOCX file (if `npm` and the `docx` package are available):** Use the docx-js
approach from the installed `docx` skill to also generate a properly formatted .docx.
Name it `resume-[Company]-[Role].docx`. Only attempt this if npm is confirmed available
— don't fail the whole task trying.

**PDF file (if the DOCX was generated AND LibreOffice is available):** Check first with
`which soffice` (or `which libreoffice`). If present, convert directly:
```bash
soffice --headless --convert-to pdf resume-[Company]-[Role].docx
```
If LibreOffice isn't installed, skip PDF silently — don't error out, and don't say you
made one. Just tell the user the plain text and DOCX are ready, and that they can export
a PDF themselves from Word or Google Docs if they need one.

Never claim a file format exists that wasn't actually written to disk — confirm each file
landed before saying it's ready.

**Verify content completeness — this matters as much as generating the file at all.**
Count the projects/experience entries in the plain-text version you wrote. Then check the
actual generated DOCX/PDF — extract its text or view it rendered — and confirm the same
entries are genuinely present and visible, not just that the file opens. Page-overflow bugs
in document generation can silently drop an entire project from the rendered output while
it stays correct in your draft text; the file will open fine and look plausible, so you
won't catch it unless you specifically check. If something fits in your text but not the
generated file, that's a layout bug, not a content decision — fix the layout, don't let the
export quietly eat content.

**Default to one page for under 5 years of experience.** If the honest, complete content
doesn't fit: first tighten spacing/margins within normal bounds (don't go below ~0.3in
margins or 10pt body text — past that it stops looking professional and risks ATS parsing
issues). If it still doesn't fit, cut the single project or bullet that's least relevant to
*this specific JD* — and say so explicitly in Step 5, the same way you'd disclose a gap.
A disclosed cut is a tailoring choice; a silent one is a bug.

### Step 5: Summarize what changed + what's missing

After the resume, give a short section:

```
CHANGES MADE
- [keyword 1]: added to [where]
- [keyword 2]: rewrote [which bullet] to include it
...

GAPS (be honest)
- [requirement]: not in your background. [brief honest note — e.g., "Ruby: listed Python/Go
  as alternatives; should be fine", or "Kafka: your task queue project covers the concept
  but not the tool — name it in a cover letter"]
- [STRENGTHEN] count: N bullets could be stronger with metrics
- File check: confirm every project in the text version also appears in the generated
  file, and note anything you cut to fit one page (and why)
```

### Step 6: Offer a cover letter

After the resume, always ask:
"Want me to draft a cover letter too? I'll use the same JD analysis — takes 30 seconds."

If yes, go to Mode 3.

---

## Mode 2: Cold Outreach Finder

Find the 3-5 highest-leverage people at a company for the user to contact.

### Step 1: Get the target

Ask for:
- Company name
- Role or team they're applying to

### Step 2: Find the email domain FIRST — before anything else

This is critical. Get the domain wrong and every email bounces.

Search in this order until you have 2+ confirming sources:

1. `"@[company.com]" email` — looks for real employee emails in public sources
2. `[company] email format site:hunter.io`
3. GitHub commits from company employees (often show real email addresses)
4. Press releases, blog post bylines, or LinkedIn contact sections
5. `[company.com] email format`

Once you have 2+ consistent results, label it **"Likely confirmed: first.last@company.com"**.
If you only have one source, label it **"Guessed from one source — verify before sending"**.
If you find nothing, say so honestly: **"Format unknown — use Hunter.io or Apollo.io"**.

Never state an email format as fact without at least two matching data points.

### Step 3: Find contacts

Run these searches:

**Recruiters / Talent Acquisition:**
- `"[Company]" "technical recruiter" OR "talent acquisition" site:linkedin.com`
- `"[Company]" "[role area] recruiter"` — e.g., "Stripe engineering recruiter"
- Check the company's LinkedIn People page → filter by "Human Resources"

**Hiring managers:**
- `"[Company]" "engineering manager" OR "head of [team]" OR "director of [team]" site:linkedin.com`
- Check the company's careers page — some list the recruiter or team name
- Search `[company] [team] team site:[company.com]` — team pages often name leads
- Check the company's engineering blog for authors on the team

**Senior ICs / peers (underrated path):**
- `"[Company]" "senior [role]" OR "staff [role]" site:linkedin.com`
- Someone hired in the last 6-18 months is often willing to help

Do 4-6 searches. Sparse results are fine — 3 real contacts beats 10 placeholders.

### Step 4: Present contacts

| Name | Title | LinkedIn | Email | Priority |
|------|-------|----------|-------|----------|
| ... | ... | linkedin.com/in/... | first.last@co.com | High |

Priority:
- **High** = direct recruiter for this role, or manager of the hiring team
- **Med** = adjacent manager, senior team member, general recruiter

Be honest: say "guessed" for emails you inferred, "confirmed" for ones you found directly.
If you couldn't find a real name for a slot, say so — don't fill in placeholders.

### Step 5: Outreach templates

Provide both. Make them company-specific, not generic.

**LinkedIn connection request (≤300 chars):**
```
Hi [Name], I'm applying for [Role] at [Company] and was genuinely drawn to [one
specific real thing about the company/team/product]. Would love to connect!
```

**Cold email:**
```
Subject: [Role] Application — Quick Question

Hi [Name],

I'm [your name], applying for [Role] at [Company]. I was drawn to [one specific,
non-generic thing — a product decision, a blog post, something real].

[One sentence on your most relevant experience for this role, with a number if possible.]

Would you be open to a 10-minute chat? No pressure — appreciate your time either way.

[Name]
[LinkedIn URL]
```

Remind them: connect on LinkedIn first, wait 2-3 days, then message. It's warmer.

**Pacing reminder (always include this when more than one contact is listed):** Tell the
user explicitly to personalize each message and not send the identical template to
multiple people at the same company on the same day — identical messages landing across
one small team reads as spam, not interest, and can quietly hurt their candidacy.
Recommend reaching out to the single highest-priority contact first and waiting to hear
back before trying a second person there.

---

## Mode 3: Cover Letter

Write a tight 3-paragraph cover letter. Reuse the JD analysis from Mode 1 if it's already
in this conversation. If it's not — a new session, or the user jumped straight to a cover
letter without tailoring a resume first — ask for the job description (and the base resume,
if you don't have that either) and run the Step 2 JD breakdown from Mode 1 before writing
anything. Don't write a cover letter against a JD you haven't actually analyzed.

**Paragraph 1 — Why this company (not generic)**
Reference something specific and real: a product decision, a recent launch, a blog post,
a mission statement that actually resonates. One sentence of genuine interest is worth
more than three sentences of flattery.

**Paragraph 2 — Why you (with evidence)**
Pick the single strongest match between the user's experience and the JD's top priority.
One tight paragraph with a concrete example and a number if they have one. Don't
summarize the whole resume — pick the best thing.

**Paragraph 3 — Close**
Express enthusiasm, note that you've attached the resume, and keep it brief. No "I
believe I would be a great fit" — show, don't tell.

Format: plain text, under 300 words total. Short cover letters get read; long ones don't.

---

## Quick tips (share after any mode)

- **ATS check:** Run the tailored resume through Jobscan or Resume Worded (both free tier)
  before submitting — they catch keyword gaps fast
- **Timing:** Apply and reach out the same day — most companies screen within 48-72 hours
  of a posting going live
- **Outreach goal:** A reply, not a referral. Ask for advice or a quick chat, not a favor
- **Follow up:** Once, after 5-7 days. Not more
